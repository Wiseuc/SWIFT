//
//  AppDelegate.h
//  NOW
//
//  Created by ArJun on 16/8/7.
//  Copyright © 2016年 ArJun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CommendViewController.h"
#import <WMPageController.h>
#import "MainBaseViewController.h"
#import "MainNavigationController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

