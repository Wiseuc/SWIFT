//
//  AppDelegate.h
//  ARDemo
//
//  Created by WHISPERS on 2017/6/7.
//  Copyright © 2017年 WHISPERS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

