//
//  CustomModel.swift
//  DemoSwift102_tableview
//
//  Created by zhangshaoyu on 16/10/21.
//  Copyright © 2016年 zhangshaoyu. All rights reserved.
//

import UIKit

class CustomModel: NSObject {

    // 标题
    var title:String!
    // 内容
    var content:String!
    // 内容显示，或隐藏状态
    var contentStatus:Bool!
}
