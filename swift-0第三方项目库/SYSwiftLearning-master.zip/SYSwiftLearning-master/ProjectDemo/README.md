# SYDemoSwift_2048
使用swift语言仿写2048游戏
